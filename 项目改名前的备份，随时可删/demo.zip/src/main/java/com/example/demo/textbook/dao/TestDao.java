package com.example.demo.textbook.dao;

public interface TestDao {
    void sayHello();
}
