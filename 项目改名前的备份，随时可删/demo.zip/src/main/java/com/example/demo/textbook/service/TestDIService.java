package com.example.demo.textbook.service;

public interface TestDIService {
    void sayHello();
}
