package com.example.demo.textbook.dao;

public class TestDaoImpl implements TestDao {

    @Override
    public void sayHello() {
        System.out.println("Hello world!");
    }

}
