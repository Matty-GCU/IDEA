package com.example.demo.textbook.dao;

public class TestDIDaoImpl implements TestDIDao {
    @Override
    public void sayHello() {
        System.out.println("Have a good day.");
    }
}
