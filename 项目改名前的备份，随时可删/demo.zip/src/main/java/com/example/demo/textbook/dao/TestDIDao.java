package com.example.demo.textbook.dao;

public interface TestDIDao {
    void sayHello();
}
