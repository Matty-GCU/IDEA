package chapter10.javabean;

/**
 * @author Matty
 * @date 2021/11/29
 */
public class StudentVO {
    private String name;
    private int id;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}