package xyz.wuhang.dao;

public class UserDao {
    public static void test() {
        System.out.println("UserDao test...aaa");
    }
}
