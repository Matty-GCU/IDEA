package system;

import org.junit.jupiter.api.Test;

class BackgroundSystemOldTest {

    @Test
    void test() {
        BackgroundSystemOld system = new BackgroundSystemOld();
        system.play();
    }

}