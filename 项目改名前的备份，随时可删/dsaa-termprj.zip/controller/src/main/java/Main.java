public class Main {
    public static void main(String[] args) {
        ConsoleControllerOld consoleControllerOld = new ConsoleControllerOld();
        consoleControllerOld.entry();
    }
}
