package system;

import org.junit.jupiter.api.Test;

class BackgroundSystemOldTest {

    @Test
    void testOld() {
        BackgroundSystemOld system = new BackgroundSystemOld();
        system.play();
    }
    
    @Test
    void testNew() {
        BackgroundSystemNew system = new BackgroundSystemNew();
        system.play();
    }
}