package pojo;

import lombok.Data;

@Data
public class Manager {
    String id;
    String pwd;
}
